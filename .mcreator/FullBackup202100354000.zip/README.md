# Erinium mods

Mod crée par @JLSkyzer

Curseforge link : https://www.curseforge.com/minecraft/mc-mods/erinium

<img alt="" src="https://img.shields.io/github/last-commit/JLSkyzer/erinium?color=lightgrey&label=Last%20update">

<h2>Information</h2>

<img src="https://i.imgur.com/uu3BrwV.png" width="500" height="300" />
<img src="https://i.imgur.com/9l3450w.png" width="500" height="300" />
<img src="https://i.imgur.com/4yiKHua.png" width="500" height="300" />
<img src="https://i.imgur.com/mQLKyAW.png" width="500" height="300" />
