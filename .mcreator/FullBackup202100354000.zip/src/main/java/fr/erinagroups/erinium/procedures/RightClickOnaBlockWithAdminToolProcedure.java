package fr.erinagroups.erinium.procedures;

import java.util.Map;

public class RightClickOnaBlockWithAdminToolProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {

	}
}
