package fr.erinagroups.erinium.procedures;

import java.util.Map;

public class EriniumCommandExecutedProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {

	}
}
