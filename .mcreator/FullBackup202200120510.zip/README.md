# Erinium mods

Mod crée par @JLSkyzer

Curseforge link : https://www.curseforge.com/minecraft/mc-mods/erinium

<img alt="" src="https://img.shields.io/github/last-commit/JLSkyzer/erinium?color=lightgrey&label=Last%20update">

<h2>Information</h2>

<p><img src="https://erinium-wiki.netlify.app/img/templates/all%20items.png" width="500" height="300" /></p>
<p><img src="https://erinium-wiki.netlify.app/img/templates/all blocks.png" width="500" height="300" /></p>
<p><img src="https://erinium-wiki.netlify.app/img/templates/all%20armors.png" width="500" height="300" /></p>
<p><img src="https://erinium-wiki.netlify.app/img/templates/scining biomes.png" width="500" height="300" /></p>
<p><img src="https://erinium-wiki.netlify.app/img/templates/space_update_blocks.png" alt="https://erinium-wiki.netlify.app/img/templates/all%20armors.png" width="500" height="300" /></p>
<p><img src="https://erinium-wiki.netlify.app/img/templates/space_update_item.png" alt="https://erinium-wiki.netlify.app/img/templates/all%20armors.png" width="500" height="300" /></p>
<p><img src="https://erinium-wiki.netlify.app/img/templates/space_update_moon.png" alt="https://erinium-wiki.netlify.app/img/templates/all%20armors.png" width="500" height="300" /></p>
