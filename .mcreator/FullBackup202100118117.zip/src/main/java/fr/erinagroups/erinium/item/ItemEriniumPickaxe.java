
package fr.erinagroups.erinium.item;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.Item;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;

import java.util.Set;
import java.util.HashMap;

import fr.erinagroups.erinium.creativetab.TabEriniumTab;
import fr.erinagroups.erinium.ElementsEriniumMod;

@ElementsEriniumMod.ModElement.Tag
public class ItemEriniumPickaxe extends ElementsEriniumMod.ModElement {
	@GameRegistry.ObjectHolder("erinium:erinium_pickaxe")
	public static final Item block = null;
	public ItemEriniumPickaxe(ElementsEriniumMod instance) {
		super(instance, 12);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemPickaxe(EnumHelper.addToolMaterial("ERINIUM_PICKAXE", 4, 2000, 12f, 0f, 30)) {
			{
				this.attackSpeed = -3f;
			}
			public Set<String> getToolClasses(ItemStack stack) {
				HashMap<String, Integer> ret = new HashMap<String, Integer>();
				ret.put("pickaxe", 4);
				return ret.keySet();
			}
		}.setUnlocalizedName("erinium_pickaxe").setRegistryName("erinium_pickaxe").setCreativeTab(TabEriniumTab.tab));
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("erinium:erinium_pickaxe", "inventory"));
	}
}
