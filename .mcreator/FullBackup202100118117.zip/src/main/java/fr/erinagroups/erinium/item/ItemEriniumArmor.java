
package fr.erinagroups.erinium.item;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;

import net.minecraft.world.World;
import net.minecraft.util.ResourceLocation;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.Item;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;

import java.util.Map;
import java.util.HashMap;

import fr.erinagroups.erinium.procedure.ProcedureEriniumArmorLeggingsTickEvent;
import fr.erinagroups.erinium.procedure.ProcedureEriniumArmorHelmetTickEvent;
import fr.erinagroups.erinium.procedure.ProcedureEriniumArmorBootsTickEvent;
import fr.erinagroups.erinium.procedure.ProcedureEriniumArmorBodyTickEvent;
import fr.erinagroups.erinium.creativetab.TabEriniumTab;
import fr.erinagroups.erinium.ElementsEriniumMod;

@ElementsEriniumMod.ModElement.Tag
public class ItemEriniumArmor extends ElementsEriniumMod.ModElement {
	@GameRegistry.ObjectHolder("erinium:erinium_armorhelmet")
	public static final Item helmet = null;
	@GameRegistry.ObjectHolder("erinium:erinium_armorbody")
	public static final Item body = null;
	@GameRegistry.ObjectHolder("erinium:erinium_armorlegs")
	public static final Item legs = null;
	@GameRegistry.ObjectHolder("erinium:erinium_armorboots")
	public static final Item boots = null;
	public ItemEriniumArmor(ElementsEriniumMod instance) {
		super(instance, 1);
	}

	@Override
	public void initElements() {
		ItemArmor.ArmorMaterial enuma = EnumHelper.addArmorMaterial("ERINIUM_ARMOR", "erinium:erinium_armor", 40, new int[]{12, 16, 16, 12}, 30,
				(net.minecraft.util.SoundEvent) net.minecraft.util.SoundEvent.REGISTRY.getObject(new ResourceLocation("")), 3f);
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.HEAD) {
			@Override
			public void onArmorTick(World world, EntityPlayer entity, ItemStack itemstack) {
				super.onArmorTick(world, entity, itemstack);
				int x = (int) entity.posX;
				int y = (int) entity.posY;
				int z = (int) entity.posZ;
				{
					Map<String, Object> $_dependencies = new HashMap<>();
					$_dependencies.put("entity", entity);
					ProcedureEriniumArmorHelmetTickEvent.executeProcedure($_dependencies);
				}
			}
		}.setUnlocalizedName("erinium_armorhelmet").setRegistryName("erinium_armorhelmet").setCreativeTab(TabEriniumTab.tab));
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.CHEST) {
			@Override
			public void onArmorTick(World world, EntityPlayer entity, ItemStack itemstack) {
				int x = (int) entity.posX;
				int y = (int) entity.posY;
				int z = (int) entity.posZ;
				{
					Map<String, Object> $_dependencies = new HashMap<>();
					$_dependencies.put("entity", entity);
					ProcedureEriniumArmorBodyTickEvent.executeProcedure($_dependencies);
				}
			}
		}.setUnlocalizedName("erinium_armorbody").setRegistryName("erinium_armorbody").setCreativeTab(TabEriniumTab.tab));
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.LEGS) {
			@Override
			public void onArmorTick(World world, EntityPlayer entity, ItemStack itemstack) {
				int x = (int) entity.posX;
				int y = (int) entity.posY;
				int z = (int) entity.posZ;
				{
					Map<String, Object> $_dependencies = new HashMap<>();
					$_dependencies.put("entity", entity);
					ProcedureEriniumArmorLeggingsTickEvent.executeProcedure($_dependencies);
				}
			}
		}.setUnlocalizedName("erinium_armorlegs").setRegistryName("erinium_armorlegs").setCreativeTab(TabEriniumTab.tab));
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.FEET) {
			@Override
			public void onArmorTick(World world, EntityPlayer entity, ItemStack itemstack) {
				int x = (int) entity.posX;
				int y = (int) entity.posY;
				int z = (int) entity.posZ;
				{
					Map<String, Object> $_dependencies = new HashMap<>();
					$_dependencies.put("entity", entity);
					ProcedureEriniumArmorBootsTickEvent.executeProcedure($_dependencies);
				}
			}
		}.setUnlocalizedName("erinium_armorboots").setRegistryName("erinium_armorboots").setCreativeTab(TabEriniumTab.tab));
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(helmet, 0, new ModelResourceLocation("erinium:erinium_armorhelmet", "inventory"));
		ModelLoader.setCustomModelResourceLocation(body, 0, new ModelResourceLocation("erinium:erinium_armorbody", "inventory"));
		ModelLoader.setCustomModelResourceLocation(legs, 0, new ModelResourceLocation("erinium:erinium_armorlegs", "inventory"));
		ModelLoader.setCustomModelResourceLocation(boots, 0, new ModelResourceLocation("erinium:erinium_armorboots", "inventory"));
	}
}
