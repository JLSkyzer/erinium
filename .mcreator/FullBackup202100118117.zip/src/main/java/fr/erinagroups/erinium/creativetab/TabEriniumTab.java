
package fr.erinagroups.erinium.creativetab;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;

import net.minecraft.item.ItemStack;
import net.minecraft.creativetab.CreativeTabs;

import fr.erinagroups.erinium.item.ItemEriniumArmor;
import fr.erinagroups.erinium.ElementsEriniumMod;

@ElementsEriniumMod.ModElement.Tag
public class TabEriniumTab extends ElementsEriniumMod.ModElement {
	public TabEriniumTab(ElementsEriniumMod instance) {
		super(instance, 7);
	}

	@Override
	public void initElements() {
		tab = new CreativeTabs("taberinium_tab") {
			@SideOnly(Side.CLIENT)
			@Override
			public ItemStack getTabIconItem() {
				return new ItemStack(ItemEriniumArmor.body, (int) (1));
			}

			@SideOnly(Side.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static CreativeTabs tab;
}
