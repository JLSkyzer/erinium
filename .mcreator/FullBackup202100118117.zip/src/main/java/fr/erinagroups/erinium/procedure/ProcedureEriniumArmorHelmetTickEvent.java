package fr.erinagroups.erinium.procedure;

import net.minecraft.potion.PotionEffect;
import net.minecraft.init.MobEffects;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;

import java.util.Map;

import fr.erinagroups.erinium.ElementsEriniumMod;

@ElementsEriniumMod.ModElement.Tag
public class ProcedureEriniumArmorHelmetTickEvent extends ElementsEriniumMod.ModElement {
	public ProcedureEriniumArmorHelmetTickEvent(ElementsEriniumMod instance) {
		super(instance, 2);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure EriniumArmorHelmetTickEvent!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof EntityLivingBase)
			((EntityLivingBase) entity).addPotionEffect(new PotionEffect(MobEffects.NIGHT_VISION, (int) 600, (int) 1, (false), (false)));
	}
}
